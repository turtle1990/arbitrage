<?php ini_set('display_errors', 1); ini_set('display_startup_errors', 1); error_reporting(E_ALL);ini_set('max_execution_time', 300); ?>


<html>
    <head>
        <title>Status of Exchange</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>

    <?php

        require_once("global.php");
        require_once("exchanges/tokenbaz.php");
        require_once("exchanges/bitimen.php");
        require_once("exchanges/changekon.php");
        require_once("exchanges/exnovin.php");
        require_once("exchanges/nobitex.php");
        require_once("exchanges/ramzinex.php");
        require_once("exchanges/dollarkadeh.php");
        include('plugin/simple_html_dom/simple_html_dom.php'); //work with html dom.
        require_once('fee.php');
        require_once("Tel_bot.php");
        require_once("arbiterage.php");

        global $exchange;

        $coins = array("USDT","XRP","DOT","XLM","TRX","BNB","MATIC","LTC","EOS","DOGE","ADA","DAI");
        // $coins = array("USDT");
        
        Changekon("ALLTYPE");// one ajax and get all cryptocurrency
        foreach ($coins as $coin){
            Tokenbaz($coin);
            Bitimen($coin);
            Changekon($coin);
            Exnovin($coin);
            Nobitex($coin);
            Ramzinex($coin);
            Dollarkadeh($coin);
            Arbitrge(0.68);
            unset($exchange);
        }

        

        // echo "<br> Number of Global Exchange: " . sizeof($GLOBALS['exchange']);

        // echo "<pre>";
        // print_r($exchange);
        // echo "</pre>";


        

    ?>

    </body>
</html>

