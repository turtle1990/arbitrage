<html>
    <head>
        <title>Status of Exchange</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>

    <?php

include ("tokenbaz.php");// get data from Tokenbaz.
include ("mihanblockchain.php");//get data from Mihanblockchain.
include ("Tel_bot.php");


Tokenbaz("USDT");
Tokenbaz("XRP");
Tokenbaz("DOT");
Tokenbaz("DOGE");
Tokenbaz("XLM");
Tokenbaz("EOS");
Tokenbaz("TRX");
Tokenbaz("ADA");
Tokenbaz("BNB");
Tokenbaz("MATIC");
Tokenbaz("DAI");

?>

    </body>
</html>

