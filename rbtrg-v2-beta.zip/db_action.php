<?php

require_once 'db_conn.php';

if(count($_POST)>0) 
{
    mysqli_query(Db_conn(),
    "UPDATE available set ID='" . $_POST['ID'] . "',
        EXCHANGE_NAME='" . $_POST['EXCHANGE_NAME'] . "', 
        RIAL='" . $_POST['RIAL'] . "',
        USDT='" . $_POST['USDT'] . "' ,
        XRP='" . $_POST['XRP'] . "' ,
        DOT='" . $_POST['DOT'] . "' ,
        DOGE='" . $_POST['DOGE'] . "' ,
        XLM='" . $_POST['XLM'] . "' ,
        EOS='" . $_POST['EOS'] . "' ,
        TRX='" . $_POST['TRX'] . "' ,
        BNB='" . $_POST['BN'] . "' ,
        MATIC='" . $_POST['MATIC'] . "' ,
        DAI='" . $_POST['DAI'] . "' 
        WHERE ID='" . $_POST['ID'] . "'
    ");
    $message = "Record Modified Successfully";
}

mysqli_close($conn);

?>