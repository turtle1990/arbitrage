<?php ini_set('display_errors', 1); ini_set('display_startup_errors', 1); error_reporting(E_ALL); ?>


<html>
    <head>
        <title>Status of Exchange</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>

    <?php

        require_once ("global.php");
        include ("exchanges/tokenbaz.php");// get data from Tokenbaz.
        // include ("mihanblockchain.php");//get data from Mihanblockchain.
        require_once("exchanges/bitimen.php");
        require_once("exchanges/changekon.php");
        require_once("exchanges/exnovin.php");
        include('plugin/simple_html_dom/simple_html_dom.php'); //work with html dom.
        include('exclude.php');
        include('fee.php');
        include ("Tel_bot.php");

        global $exchange;

        $coins = array("USDT","XRP","DOT","XLM","TRX","DOGE","BNB","MATIC","LTC","DAI","ADA","EOS");
        // $coins = array("ADA");
        
        Changekon("ALLTYPE");// one ajax and get all cryptocurrency
        foreach ($coins as $coin){
            Tokenbaz($coin);
            Bitimen($coin);
            Changekon($coin);
            Exnovin($coin);
            Arbitrge(0.68);
            unset($exchange);
        }

        

        // echo "<br> Number of Global Exchange: " . sizeof($GLOBALS['exchange']);

        // echo "<pre>";
        // print_r($exchange);
        // echo "</pre>";


        

    ?>

    </body>
</html>

